
//////  login controller to check and validate the user who has logged in///////


(function () {

    'use strict';

    //get the module and invoke controller function   

    angular.module('app.pages.login').controller('loginController', ['$scope', '$http', '$state', '$cookies', 'loginServices', fnLoginController]);
    /* jshint validthis: true */

    function fnLoginController($scope, $http, $state, $cookies, loginServices) {

        var loginViewModel = this;
        loginViewModel.loginData = { UserId: 0, Email: "", Role: "", IsAuthenticated: false, Password: "" };
        loginViewModel.Title = "Login";
        loginViewModel.login = loginService;
        loginViewModel.loginAuthenticatedData = {};
        loginViewModel.loginmessage = { ErrorMessage: "", ServiceErrorMessage: "Sorry ,You are not Authorized Person to Login..." };

        loginViewModel.isProcessed = false;

        function loginService() {
            loginViewModel.isProcessed = true;
            var validateUser = loginServices.loginUser(loginViewModel.loginData);

            ////////////// Route the user based on authentication /////////////
                   validateUser.then(function (loginResponse) {
                loginViewModel.loginAuthenticatedData = loginResponse.data;
                // alert(loginViewModel.loginAuthenticatedData.IsValid);
                if (loginResponse != null && loginViewModel.loginAuthenticatedData.IsValid == true) {

                    //show dashborad to authenticated user//
                    $cookies.Email = loginViewModel.loginAuthenticatedData.Email;
                    $cookies.put("MS_USER", loginViewModel.loginAuthenticatedData.Email);
                    var MSUser = $cookies.get("MS_USER");
                                       $state.go('main');
                    // $state.go('Welcome', {}, { reload: true });
                    //$state.go($state.current, {}, { reload: true });
                    console.log('logged in successfully.');
                } else {

                    loginViewModel.loginmessage.ErrorMessage = loginViewModel.loginAuthenticatedData.ErrorMessage;
                }

            }, function (loginfailResponse) {
                loginViewModel.loginAuthenticatedData = loginfailResponse.data;
                //// when authentication fails becasue of some failure of system
                if (loginfailResponse.status == "-1") {

                    loginViewModel.loginmessage.ErrorMessage = loginViewModel.loginmessage.ServiceErrorMessage;
                    console.log('log-in failed. API Services are down');
                } else {

                    if (loginfailResponse == null || loginfailResponse.data == null) {
                        // alert('fail login');
                        loginViewModel.loginmessage.ErrorMessage = loginViewModel.loginmessage.ServiceErrorMessage;
                        console.log('log-in failed')
                    } else {

                        if (loginfailResponse != null && loginViewModel.loginAuthenticatedData.IsValid == false) {
                            loginViewModel.loginmessage.ErrorMessage = loginViewModel.loginAuthenticatedData.ErrorMessage;
                            console.log('log-in failed.');
                        }
                    }
                }

                if (loginfailResponse.status == "500" || loginfailResponse.status == "404") {

                    loginViewModel.loginmessage.ErrorMessage = loginViewModel.loginmessage.ServiceErrorMessage;
                    console.log(loginfailResponse.data);
                }

            }).finally(function (reset) {

                loginViewModel.isProcessed = false;
            });

            ////////////// END Route the user based on authentication /////////////

        }
    }


})();