(function () {
    'use strict';

    angular.module('app.pages.login', []).config(routeConfig);

    /** @ngInject */
    function routeConfig($stateProvider) {
        $stateProvider
            .state('login', {
                url: '/login',
                templateUrl: 'app/pages/login/login.html'

                //sidebarMeta: {
                //    icon: 'fa fa-home',
                //    order: 0,
                //},
            });
    }

    angular.module('app.pages.login').constant("utility", { baseAddress: "http://localhost:50902/api/" });

})();