(function () {
    'use strict';

    angular.module('app.pages.main', [])
      .config(routeConfig);

    /** @ngInject */
    function routeConfig($stateProvider) {
        $stateProvider
            .state('main', {
                url: '/main',
                
                templateUrl: 'app/pages/main/main.html',
                sidebarMeta: {
                    icon: 'ion-android-home',
                    order: 0,
                },

            });
    }

})();
//////////// i am integrating based on blur admin
// folder structure is like  - app->pages->login
//app->pages->main
//index.html is root file 
//login.html is also at root level